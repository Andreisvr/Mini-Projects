package com.example.project;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Suma#} factory method to
 * create an instance of this fragment.
 */
public class Suma extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private EditText procentLunaraEditText, sumaLunaraEditText, perioadaTotalaEditText;
    private CheckBox suplyMonthlyCheckBox, suplyAnnualCheckBox;
    private Button calculateButton;
    private TextView resultTextView;

    public Suma() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Suma.
     */
    // TODO: Rename and change types and number of parameters
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_suma, container, false);

        procentLunaraEditText = rootView.findViewById(R.id.procent_anual);
        sumaLunaraEditText = rootView.findViewById(R.id.suma_lunara);
        perioadaTotalaEditText = rootView.findViewById(R.id.perioada_totala);
        suplyMonthlyCheckBox = rootView.findViewById(R.id.monthly_payment);
        suplyAnnualCheckBox = rootView.findViewById(R.id.total_overpay);
        calculateButton = rootView.findViewById(R.id.button4);
        resultTextView = rootView.findViewById(R.id.rezultat);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateYears();
            }
        });

        return rootView;
    }

    private void calculateYears() {

        if (procentLunaraEditText.getText().toString().isEmpty() ||
                sumaLunaraEditText.getText().toString().isEmpty() ||
                perioadaTotalaEditText.getText().toString().isEmpty()) {
            Toast.makeText(getContext(), "Complete all fields", Toast.LENGTH_SHORT).show();
            return;
        }


        double procentAnual = Double.parseDouble(procentLunaraEditText.getText().toString());
        double sumaLunara = Double.parseDouble(sumaLunaraEditText.getText().toString());
        double perioadaTotala = Double.parseDouble(perioadaTotalaEditText.getText().toString());


        boolean isMonthly = suplyMonthlyCheckBox.isChecked();
        boolean isAnnualy = suplyAnnualCheckBox.isChecked();

        if (isMonthly && isAnnualy) {
            Toast.makeText(getActivity(), "Select only one mode", Toast.LENGTH_SHORT).show();
            return;
        }

        int ani = (int) (perioadaTotala / 12);
        int luni = (int) (perioadaTotala % 12);
        double procentLuni = ((procentAnual / 12.0) * luni)/100;
        double rataAnuala = procentAnual / 100;

        if (isMonthly) {
            suplyAnnualCheckBox.setChecked(false);
            double sumaFinala = 1;

            if (ani > 0) {
                for (int i = 0; i < ani; i++) {
                    sumaFinala += sumaLunara * 12 ;
                    sumaFinala+= sumaFinala*rataAnuala;
                }
            }
            if (luni > 0) {
                sumaFinala += sumaLunara * procentLuni;
                sumaFinala += sumaFinala*luni;
            }
            resultTextView.setText("Aprox sum: " + String.format("%.2f", sumaFinala));
        }

        else if (isAnnualy) {
        double sumaFinala =1;
            if (ani > 0) {
                for (int i = 0; i < ani; i++) {
                    sumaFinala += sumaLunara  ;
                    sumaFinala+= sumaFinala*rataAnuala;
                }
            }
            if (luni > 0) {
                sumaFinala += sumaLunara * procentLuni;
                sumaFinala += sumaFinala*luni;
            }
            resultTextView.setText("Aprox sum: " + String.format("%.2f", sumaFinala));
        }
    }



}
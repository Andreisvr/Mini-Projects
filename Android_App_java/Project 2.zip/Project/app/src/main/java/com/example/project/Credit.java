package com.example.project;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Credit extends AppCompatActivity {

    private EditText procentAnualEditText, sumaTotalaEditText, perioadaEditText;
    private CheckBox monthlyPaymentCheckBox, totalOverpayCheckBox;
    private Button calculateButton;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit);

        procentAnualEditText = findViewById(R.id.procent_anual);
        sumaTotalaEditText = findViewById(R.id.suma_totala);
        perioadaEditText = findViewById(R.id.suma_lunara);
        monthlyPaymentCheckBox = findViewById(R.id.monthly_payment);
        totalOverpayCheckBox = findViewById(R.id.total_overpay);
        calculateButton = findViewById(R.id.button4);
        resultTextView = findViewById(R.id.rezultat);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateResult();
            }
        });
    }

    private void calculateResult() {
        if (procentAnualEditText.getText().toString().isEmpty() ||
                sumaTotalaEditText.getText().toString().isEmpty() ||
                perioadaEditText.getText().toString().isEmpty()) {
            Toast.makeText(this, "Complete all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double procentAnual = Double.parseDouble(procentAnualEditText.getText().toString());
        double sumaTotal = Double.parseDouble(sumaTotalaEditText.getText().toString());
        double perioada = Double.parseDouble(perioadaEditText.getText().toString());

        int ani = (int) (perioada / 12);
        int luni = (int) (perioada % 12);
        double procentLuni = ((procentAnual / 12.0) * luni)/100;

        if (monthlyPaymentCheckBox.isChecked() && totalOverpayCheckBox.isChecked()) {
            Toast.makeText(this, "Select only one option", Toast.LENGTH_SHORT).show();
            return;
        }

        if (monthlyPaymentCheckBox.isChecked()) {
            double totalPlata = sumaTotal;
            double procent = procentAnual/100;
            if (ani > 0) {
                for (int i = 0; i < ani; i++) {
                    totalPlata += totalPlata * procent;
                }
            }
            if (luni > 0) {
                totalPlata += totalPlata * procentLuni;
            }

            double rataLunara = totalPlata/(12 * ani + luni);
            resultTextView.setText(String.format("Monthly sum:\n   %.2f", rataLunara));
        } else if (totalOverpayCheckBox.isChecked()) {
            double totalPlata = sumaTotal;
            double procent = procentAnual/100;
            if (ani > 0) {
                for (int i = 0; i < ani; i++) {
                    totalPlata += totalPlata * procent;
                }
            }
            if (luni > 0) {
                totalPlata += totalPlata * procentLuni;
            }
            resultTextView.setText(String.format("Total overpay:\n   %.2f", totalPlata - sumaTotal));
        }
    }

}

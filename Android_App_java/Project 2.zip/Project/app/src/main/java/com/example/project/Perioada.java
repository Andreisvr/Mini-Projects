package com.example.project;

import android.os.Bundle;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class Perioada extends Fragment {

    private EditText procentLunaraEditText, sumaLunaraEditText, sumaTotalaEditText;
    private CheckBox suplyMonthlyCheckBox, suplyAnnualCheckBox;
    private Button calculateButton;
    private TextView resultTextView;

    public Perioada() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_perioada, container, false);

        procentLunaraEditText = rootView.findViewById(R.id.procent_anual);
        sumaLunaraEditText = rootView.findViewById(R.id.suma_lunara);
        sumaTotalaEditText = rootView.findViewById(R.id.suma_totala);
        suplyMonthlyCheckBox = rootView.findViewById(R.id.monthly_payment);
        suplyAnnualCheckBox = rootView.findViewById(R.id.total_overpay);
        calculateButton = rootView.findViewById(R.id.button4);
        resultTextView = rootView.findViewById(R.id.rezultat);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateYears();
            }
        });

        return rootView;
    }

    private void calculateYears() {

        if (procentLunaraEditText.getText().toString().isEmpty() ||
                sumaLunaraEditText.getText().toString().isEmpty() ||
                sumaTotalaEditText.getText().toString().isEmpty()) {
            Toast.makeText(getContext(), "Complet all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Preiați valorile introduse
        double procentAnual = Double.parseDouble(procentLunaraEditText.getText().toString());
        double sumaLunara = Double.parseDouble(sumaLunaraEditText.getText().toString());
        double sumaTotala = Double.parseDouble(sumaTotalaEditText.getText().toString());

        // Verificare selectare checkbox
        boolean isMonthly = suplyMonthlyCheckBox.isChecked();
        boolean isAnnualy = suplyAnnualCheckBox.isChecked();

        if (isMonthly && isAnnualy) {
            Toast.makeText(getActivity(), "Select only one mode", Toast.LENGTH_SHORT).show();
            return;
        }
        double rataAnuala = procentAnual / 100;
        double rataLunara = rataAnuala / 12;





        if (isMonthly) {
            suplyAnnualCheckBox.setChecked(false);


            double numarLuniNecesare = Math.log((sumaTotala * rataLunara / sumaLunara) + 1) / Math.log(1 + rataLunara);


            resultTextView.setText("Months: " + String.format("%.1f", numarLuniNecesare));
        }
        if (isAnnualy) {

            suplyMonthlyCheckBox.setChecked(false);


            double numarAniNecesari = Math.log((sumaTotala * rataAnuala / sumaLunara) + 1) / Math.log(1 + rataAnuala);


            double numarLuni = numarAniNecesari * 12;


            resultTextView.setText("Months: " + String.format("%.0f", numarLuni) + ", ani: " + String.format("%.1f", numarAniNecesari));
        }
    }


}
